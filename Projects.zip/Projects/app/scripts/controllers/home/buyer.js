'use strict';

/**
 * @ngdoc function
 * @name projectsApp.controller:HomeBuyerCtrl
 * @description
 * # HomeBuyerCtrl
 * Controller of the projectsApp
 */
 //buyer
angular.module('projectsApp')
  .controller('HomeBuyerCtrl',[ function () {

    var view = this;

    view.init = function(){

      console.log('seller');
    };



    view.init();

  }]);
