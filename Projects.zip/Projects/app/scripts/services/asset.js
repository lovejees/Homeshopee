'use strict';

/**
 * @ngdoc service
 * @name projectsApp.ASSET
 * @description
 * # ASSET
 * Constant in the projectsApp.
 */
angular.module('projectsApp')
  .constant('ASSET', {
    
  });
